import jwt from 'jsonwebtoken'
import { userSch } from '../models/users.js';

export const isAuth = async (req, res, next) => {
    const { token } = req.cookies;

    console.log(token)

    if (!token) {
        return res.status(404).json({
            success: false,
            message: "Please Login ...!"
        })
    }

    const decode = jwt.verify(token, process.env.JWT_SECRET)
    // console.log(decode);

    req.user = await userSch.findById(decode._id)

    console.log(req.user);

    next()
}

