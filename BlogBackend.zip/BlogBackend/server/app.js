import express from 'express'
import mongoose from 'mongoose';
import { config } from 'dotenv';
import cors from 'cors'
import userRouter from './routers/user.js';
import cookieParser from 'cookie-parser';
import brouter from './routers/blog.js';
const app = express()

config({ path: './data/config.env' })

const connectDb = async () => {
    const db = await mongoose.connect(process.env.MONGO_URL)
    console.log("Database connected")
}

connectDb();

app.use(express.json());
app.use(cookieParser())
app.use(cors({
    origin: [process.env.FRONTEND_URL],
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true
}))


const port = 4000;

app.use('/user/api', userRouter)
app.use('/user/api', brouter)

const PORT = process.env.PORT

app.listen(PORT, () =>
    console.log(`server is running at port number ${PORT} in ${process.env.NODE_ENV}`)
)