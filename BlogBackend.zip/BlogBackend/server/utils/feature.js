import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'
export const generateCookie = (response, res, statuscode = 200, message) => {
    const token = jwt.sign({ _id: response._id }, process.env.JWT_SECRET)

    console.log(token);

    res.status(200).cookie("token", token, {
        httpOnly: true, maxAge: 1000 * 60 * 1000,
        sameSite: process.env.NODE_ENV === "Devlopment" ? "lax" : "none",
        secure: process.env.NODE_ENV === "Devlopment" ? false : true
    }).json(
        {
            success: true,
            message,
        }
    )
}