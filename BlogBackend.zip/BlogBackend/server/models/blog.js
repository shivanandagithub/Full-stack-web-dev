import mongoose from "mongoose";

const blogSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            require: true,
        },

        description: {
            type: String,
            require: true,
        },

        imageUrl: {
            type: String,
            require: true,
        },

        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "userSchema",
            require: true
        },

        createdAt: {
            type: Date,
            default: Date.now
        }
    }
)

export const blogSch = mongoose.model('blogs', blogSchema);