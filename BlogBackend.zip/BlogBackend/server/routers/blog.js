import express from 'express'
import { isAuth } from '../middleware/auth.js';
import { createBlog, deleteBlog, getBlog, updateBlog } from '../controllers/blog.js';

const brouter = express.Router();


brouter.post('/createblog', isAuth, createBlog);
brouter.get('/myblogs', isAuth, getBlog);
brouter.put('/updateblog/:id', isAuth, updateBlog);
brouter.delete('/deleteblog/:id', isAuth, deleteBlog);



export default brouter;