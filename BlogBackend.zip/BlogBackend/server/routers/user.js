import express from 'express'
import { getMyProfile, login, logout, register } from '../controllers/users.js';
import { isAuth } from '../middleware/auth.js';

const router = express.Router();

router.post('/register', register)

router.post('/login', login)

router.get('/logout', logout)

router.get('/myprofile', isAuth, getMyProfile)


export default router;