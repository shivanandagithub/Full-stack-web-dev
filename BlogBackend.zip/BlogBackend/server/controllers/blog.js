import { blogSch } from "../models/blog.js";

export const createBlog = async (req, res) => {
    const { title, description, imageUrl } = req.body;
    await blogSch.create({ title, description, imageUrl, user: req.user })
    return res.status(201).send({
        success: true,
        message: "Blog Added successfully"
    })
}

export const getBlog = async (req, res) => {
    const id = req.user._id;


    const blogs = await blogSch.find({ user: id })


    if (!blogs) {
        return res.status(404).send({
            success: false,
            message: "No data found"
        })
    }

    return res.status(201).send({
        success: true,
        blogs: blogs
    })

}

export const updateBlog = async (req, res) => {
    const { title, description, imageUrl } = req.body;

    const id1 = req.params.id;

    const updatedblog = await blogSch.findByIdAndUpdate(id1, {
        title, description, imageUrl
    })

    if (!updatedblog) {
        return res.status(404).send({
            success: false,
            message: "No data found to update"
        })
    }

    return res.status(201).send({
        success: true,
        blogs: updatedblog,
        blog1: updatedblog
    })

}

export const deleteBlog = async (req, res) => {
    const id1 = req.params.id;

    const deleteblog = await blogSch.findById(id1)

    if (!deleteblog) {
        return res.status(404).send({
            success: false,
            message: "No data found to delete"
        })
    }

    const deletedblog = await blogSch.findByIdAndDelete(id1)

    return res.status(201).send({
        success: true,
        "message": "blog deleted"
    })


}