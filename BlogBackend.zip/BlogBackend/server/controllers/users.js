import { userSch } from '../models/users.js';
import bcrypt from 'bcrypt'
import { generateCookie } from '../utils/feature.js';

export const register = async (req, res) => {
    const { name, email, password } = req.body;
    const existUser = await userSch.findOne({ email });

    if (existUser) {
        return res.status(404).send({
            success: false,
            result: "User already exists"
        })
    }

    const hashPassword = await bcrypt.hash(password, 10);
    const response = await userSch({
        name, email, password: hashPassword
    }).save();

    generateCookie(response, res, 201, "user registered successfully")


}

export const login = async (req, res) => {
    const { email, password } = req.body;
    const existUser = await userSch.findOne({ email });

    if (!existUser) {
        return res.status(400).send({
            success: false,
            result: "user not found"
        })
    }

    const isMatch = await bcrypt.compare(password, existUser.password);

    if (!isMatch) {
        return res.status(500).send({
            success: false,
            result: "Invalid credentials"
        })
    }

    generateCookie(existUser, res, 200, "Login successfull")

}

export const logout = async (req, res) => {
    res.status(200).cookie("token", "", {
        expires: new Date(Date.now())
    }).json({
        success: true,
        message: 'logout successfully'
    })
}

export const getMyProfile = (req, res) => {

    return res.status(200).send({

        success: true,
        user1: req.user
    })

}



