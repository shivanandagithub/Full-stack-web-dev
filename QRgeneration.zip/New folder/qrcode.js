let url = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={data}";
let qr = document.querySelector(".container img");
let searchBox = document.querySelector(".container input");
let searchButton = document.querySelector(".container button");
function generateQRCode()
{
    if(searchBox.value.length > 0)
    {
    let data1 = searchBox.value;
    qr.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${data1}`;
    qr.style.display = 'block'
    qr.style.transition= 'max-height 1s ease-in';
    qr.style.overflow = 'hidden'
    qr.style.maxHeight = '200px'
    qr.style.width = '200px';
    qr.style.marginTop = '10px';
    qr.style.marginBottom = '40px';
    qr.style.marginLeft = 'auto';
    qr.style.marginRight = 'auto';
    }
    else
    {
        qr.style.display = 'none' 
    }
}
searchButton.addEventListener("click" , ()=>{
    generateQRCode();
})